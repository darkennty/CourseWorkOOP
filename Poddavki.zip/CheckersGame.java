import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static consts.Consts.SIZE;

public class CheckersGame extends JFrame implements ActionListener {

    private JPanel panel = new JPanel();

    private JButton[][] board = new JButton[SIZE][SIZE];

    private CheckerPiecesColors[][] pieces;

    private JButton selectedButton;

    private Color movablePieceColor;

    public CheckersGame() {
        super("Checkers Surrender");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GridLayout layout = new GridLayout(SIZE, SIZE, 0, 0);
        panel.setLayout(layout);

        initializeBoard();

        this.add(panel);
    }

    public void initializeBoard() {
        pieces = new CheckerPiecesColors[SIZE][SIZE];

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if ((i + j) % 2 == 1) {
                    if (i <= 2) {
                        board[i][j] = new JButton(new ImageIcon("C:\\black_checker.PNG"));
                        pieces[i][j] = new CheckerPiecesColors(Color.BLACK);
                    } else if (i >= 5) {
                        board[i][j] = new JButton(new ImageIcon("C:\\white_checker.PNG"));
                        pieces[i][j] = new CheckerPiecesColors(Color.WHITE);
                    } else {
                        board[i][j] = new JButton();
                    }
                    board[i][j].setBackground(Color.decode("#755C48"));
                } else {
                    board[i][j] = new JButton();
                    board[i][j].setBackground(Color.decode("#D2B48C"));
                }
                board[i][j].setPreferredSize(new Dimension(60,60));
                board[i][j].addActionListener(this);
                panel.add(board[i][j]);
            }
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        JButton buttonClicked = (JButton) e.getSource();
        int row = findRow(buttonClicked);
        int col = findCol(buttonClicked);

        if ((row + col) % 2 == 1) {
            if (selectedButton == null && pieces[row][col] != null) {
                selectedButton = buttonClicked;
                movablePieceColor = pieces[row][col].getColor();
            } else {
                int fromRow = findRow(selectedButton);
                int fromCol = findCol(selectedButton);
                int toRow = findRow(buttonClicked);
                int toCol = findCol(buttonClicked);

                final int rowDiff = Math.abs(fromRow - toRow);
                final int colDiff = Math.abs(fromCol - toCol);

                final int middleCheckerRow = (fromRow + toRow) / 2;
                final int middleCheckerCol = (fromCol + toCol) / 2;

                if (rowDiff == 1 && colDiff == 1 && pieces[toRow][toCol] == null) {
                    pieces[toRow][toCol] = pieces[fromRow][fromCol];
                    pieces[fromRow][fromCol] = null;
                } else if (rowDiff == 2 && colDiff == 2 && pieces[toRow][toCol] == null && !(pieces[middleCheckerRow][middleCheckerCol].getColor().equals(movablePieceColor))) {
                    pieces[toRow][toCol] = pieces[fromRow][fromCol];
                    pieces[fromRow][fromCol] = null;
                    pieces[middleCheckerRow][middleCheckerCol] = null;
                }

                updateBoard();

                selectedButton = null;
            }
        }
    }

    private int findRow(JButton button) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == button) {
                    return i;
                }
            }
        }
        return -1;
    }

    private int findCol(JButton button) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == button) {
                    return j;
                }
            }
        }
        return -1;
    }

    public void updateBoard() {
        int whiteCheckersCounter = 0;
        int blackCheckersCounter = 0;

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (pieces[i][j] != null) {
                    if (pieces[i][j].getColor().equals(Color.WHITE)) {
                        ++whiteCheckersCounter;
                        board[i][j].setIcon(new ImageIcon("C:\\white_checker.png"));
                    } else if (pieces[i][j].getColor().equals(Color.BLACK)) {
                        ++blackCheckersCounter;
                        board[i][j].setIcon(new ImageIcon("C:\\black_checker.png"));
                    }
                } else {
                    board[i][j].setIcon(null);
                }
            }
        }

        if (whiteCheckersCounter == 0) {

        } else if (blackCheckersCounter == 0) {

        }
    }
}
