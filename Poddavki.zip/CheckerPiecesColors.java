import java.awt.*;

public class CheckerPiecesColors {

    public Color color;

    public CheckerPiecesColors(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }
}
