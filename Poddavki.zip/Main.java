public class Main {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.pack();
        menu.setLocationRelativeTo(null);
        menu.setVisible(true);
    }
}