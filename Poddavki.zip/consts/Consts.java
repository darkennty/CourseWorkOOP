package consts;

public interface Consts {
    int SIZE = 8;
}
